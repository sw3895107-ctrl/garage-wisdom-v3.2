const search = document.getElementById("search");
const results = document.getElementById("results");

search.addEventListener("input", async () => {
  const res = await fetch("/api/search", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ query: search.value })
  });

  const data = await res.json();

  results.innerHTML = data.map(d =>
    `<div onclick="openDetails('${d.code}')">${d.code} - ${d.text}</div>`
  ).join("");
});

async function openDetails(code){
  const res = await fetch("/api/details", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ code })
  });

  const data = await res.json();

  alert(data.code + "\n" + data.title + "\n\nSteps:\n" + data.steps.join("\n"));
}

async function askAI(){
  const prompt = document.getElementById("aiInput").value;

  const res = await fetch("/api/ai", {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ prompt })
  });

  const data = await res.json();

  document.getElementById("aiResponse").innerText = data.reply;
}
