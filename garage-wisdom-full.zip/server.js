import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import OpenAI from 'openai';

const app = express();
const port = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const fixes = JSON.parse(fs.readFileSync(path.join(__dirname, 'data/fixes.json')));

// Search API
app.post('/api/search', (req, res) => {
  const { query } = req.body;

  const results = fixes.filter(f =>
    f.code.includes(query.toUpperCase()) ||
    f.text.toLowerCase().includes(query.toLowerCase())
  );

  res.json(results);
});

// Details API
app.post('/api/details', (req, res) => {
  const { code } = req.body;
  const item = fixes.find(f => f.code === code);

  if (!item) {
    return res.json({ error: "Not found" });
  }

  res.json({
    code: item.code,
    title: item.text,
    steps: [
      "Scan vehicle",
      "Inspect wiring and sensors",
      "Test components",
      "Replace faulty parts",
      "Clear codes"
    ],
    cost: "$100 - $600",
    difficulty: "Moderate"
  });
});

// AI endpoint (optional OpenAI)
app.post('/api/ai', async (req, res) => {
  const { prompt } = req.body;

  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.json({ reply: "AI not configured. Add OPENAI_API_KEY." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a car diagnostic assistant." },
        { role: "user", content: prompt }
      ]
    });

    res.json({ reply: response.choices[0].message.content });

  } catch (err) {
    res.json({ reply: "AI error" });
  }
});

app.listen(port, () => {
  console.log("Server running on port", port);
});
